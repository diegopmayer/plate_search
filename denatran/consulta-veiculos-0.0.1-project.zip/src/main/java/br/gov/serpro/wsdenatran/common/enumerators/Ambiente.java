package br.gov.serpro.wsdenatran.common.enumerators;

public enum Ambiente {
    HOMOLOGACAO, PRODUCAO, DESENVOLVIMENTO
}
