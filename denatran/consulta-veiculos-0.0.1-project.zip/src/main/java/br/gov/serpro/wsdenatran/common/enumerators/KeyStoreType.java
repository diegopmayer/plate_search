package br.gov.serpro.wsdenatran.common.enumerators;

public enum KeyStoreType {
    PKCS12, JKS
}
