package br.gov.serpro.wsdenatran.enumerators;

public enum TipoPesquisa {
    PLACA, CHASSI
}
